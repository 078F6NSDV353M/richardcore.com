import {
  deleteSelectedTextLabels,
  deleteSelectedZone,
  deleteSelectedNodes
} from "../hub.js";

export function deleteSelection() {
  deleteSelectedTextLabels();
  deleteSelectedZone();
  deleteSelectedNodes();
}

export function initDeleteController() {
  window.addEventListener(
    "construct:delete-selected",
    () => {
      deleteSelection();
    }
  );
}
